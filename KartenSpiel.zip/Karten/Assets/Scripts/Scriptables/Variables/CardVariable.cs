﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName ="Variables/Card Variable")]

public class CardVariable : ScriptableObject
{
    public CardDistance value;

    public void Set(CardDistance v)
    {
        value = v;
    }
}
