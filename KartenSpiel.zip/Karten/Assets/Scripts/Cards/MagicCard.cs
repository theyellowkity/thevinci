﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(menuName = "Card/Magic")]
public class MagicCard : CardType
{
    public override void OnSetType(Cardvis vis)
    {
        base.OnSetType(vis);

        vis.statsHolder.SetActive(false);
    }
}