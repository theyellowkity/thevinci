﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(menuName = "Elements/Text")]
public class ElementText : Element
{

    

    }
