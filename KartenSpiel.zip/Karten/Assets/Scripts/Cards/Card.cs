﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;



[CreateAssetMenu(menuName = "Card")]
public class Card : ScriptableObject
{
    public CardType cardType;
    public CardProperties[] properties;

}

