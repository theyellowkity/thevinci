﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(menuName ="Card/Creature")]
public class CreatureCard : CardType
{
    public override void OnSetType(Cardvis vis)
    {
        base.OnSetType(vis);
        vis.statsHolder.SetActive(true);
    }
}
