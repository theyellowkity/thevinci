﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(menuName="Elements/Image")]
public class ElementImage : Element
{



}
