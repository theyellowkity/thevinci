﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(menuName ="Elements/Int")]
public class ElementInt : Element
{

    
}
