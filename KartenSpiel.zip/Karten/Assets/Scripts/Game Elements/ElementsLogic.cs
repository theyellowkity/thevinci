﻿using UnityEngine;
using System.Collections;

namespace cb.GameElements
{

    public abstract class ElementsLogic : ScriptableObject
    {
        public abstract void OnClick(CardDistance inst);

        public abstract void OnHighlight(CardDistance inst);
    }
}