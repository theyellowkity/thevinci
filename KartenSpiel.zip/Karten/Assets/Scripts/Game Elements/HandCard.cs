﻿using UnityEngine;
using System.Collections;

namespace cb.GameElements
{
    [CreateAssetMenu(menuName = "Game Elements/My Hand Card")]
    public class HandCard : ElementsLogic
    {
        public SO.GameEvent onCurrentCardSelected;
        public CardVariable currentCard;
        public cb.GameStates.State holdingCard;

        public override void OnClick(CardDistance inst)
        {
            currentCard.Set(inst);
            Settings.gameManager.SetState(holdingCard);
            onCurrentCardSelected.Raise();
        }

        public override void OnHighlight(CardDistance inst)
        {

        }
    }
}
 