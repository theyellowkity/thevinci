﻿using UnityEngine;
using System.Collections;

namespace cb.GameElements
{
    [CreateAssetMenu(menuName = "Game Elements/My Card Down")]
    public class MyCardDown : ElementsLogic
    {
        public override void OnClick(CardDistance inst)
        {
            Debug.Log("This card also is mine but on the table");
        }

        public override void OnHighlight(CardDistance inst)
        {

        }
    }
}