﻿using UnityEngine;
using System.Collections;

public class CardDistance : MonoBehaviour, Clickable
{
    public Cardvis vis;
    public cb.GameElements.ElementsLogic currentLogic;

       void Start()
    {
        vis = GetComponent<Cardvis>();
    }

    public void Onclick()
    {
        if (currentLogic == null)
            return;

        currentLogic.OnClick(this);
    }

    public void OnHighlight()
    {
        if (currentLogic == null)
            return;

        currentLogic.OnHighlight(this);
    }
}
