﻿using UnityEngine;
using System.Collections;

public interface Clickable
{
    void Onclick();

    void OnHighlight();
}
