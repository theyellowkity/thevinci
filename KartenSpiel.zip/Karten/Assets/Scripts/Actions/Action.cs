﻿using UnityEngine;
using UnityEditor;
using System.Collections;

namespace cb.GameStates
{
    public abstract class Action : ScriptableObject
    {
        public abstract void Execute(float d);
    }
}