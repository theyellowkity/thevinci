﻿using cb.GameStates;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace cb.Gamestates
{
    [CreateAssetMenu(menuName = "Action/OnMouseClick")]
    public class OnMouseClick : Action
    {
        public override void Execute(float d)
        {
            if (Input.GetMouseButtonDown(0))
            {

                List<RaycastResult> results = Settings.GetUIObjs();


                foreach (RaycastResult r in results)
                {
                    Clickable c = r.gameObject.GetComponentInParent<Clickable>();

                    if (c != null)
                    {
                        c.Onclick();
                        break;
                    }
                }
            }
        }
    }
}