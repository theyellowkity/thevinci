﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using cb.GameStates;



[CreateAssetMenu(menuName = "Action/MouseDetection")]
public class MouseDetection : Action
{
    public override void Execute(float d)
    {

        List<RaycastResult> results = Settings.GetUIObjs();
        
        Clickable c = null;


        foreach (RaycastResult r in results)
        {
            c = r.gameObject.GetComponentInParent<Clickable>();

            if (c != null)
            {
                c.OnHighlight();
                break;
            }
        }
    }
}