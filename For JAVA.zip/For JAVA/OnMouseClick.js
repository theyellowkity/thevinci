﻿import cb.GameStates;
import System.Collections;
import System.Collections.Generic;
import UnityEngine;
import UnityEngine.EventSystems;

    public class OnMouseClick extends Action {
        
        public override void Execute(float d) 
          {

            if (Input.GetMouseButtonDown(0))
            {
                List<RaycastResult> results = Settings.GetUIObjs();
                for (RaycastResult r : results)
                   {
                    Clickable c = r.gameObject.GetComponentInParent<Clickable>();
                    if ((c != null)) {
                        c.Onclick();
                        break;
                    }
                    
                }
                
            }
            
   