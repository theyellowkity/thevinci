﻿import UnityEngine;
import System.Collections;

public class MagicCard extends CardType {
    
    public override void OnSetType(Cardvis vis) {
        super.OnSetType(vis);
        vis.statsHolder.SetActive(false);
    }
}