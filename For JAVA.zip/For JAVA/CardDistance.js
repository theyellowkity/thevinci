﻿import UnityEngine;
import System.Collections;
public class CardDistance extends MonoBehaviour, Clickable {
    
    public Cardvis vis;
    
    public cb.GameElements.ElementsLogic currentLogic;
    
    final void Start() {
        this.vis = GetComponent<Cardvis>();
    }
    
    public final void Onclick() {
        if ((this.currentLogic == null)) {
            return;
        }
        
        this.currentLogic.OnClick(this);
    }
    
    public final void OnHighlight() {
        if ((this.currentLogic == null)) {
            return;
        }
        
        this.currentLogic.OnHighlight(this);
    }
}