﻿import UnityEngine;
import UnityEditor;
import System.Collections;

    
    public abstract class Action extends ScriptableObject {
        
        public abstract void Execute(float d);
    }
}