﻿import UnityEngine;
import System.Collections;


    public class HandCard extends ElementsLogic {
        
        public SO.GameEvent onCurrentCardSelected;
        
        public CardVariable currentCard;
        
        public cb.GameStates.State holdingCard;
        
        public override void OnClick(CardDistance inst) {
            this.currentCard.Set(inst);
            Settings.gameManager.SetState(this.holdingCard);
            this.onCurrentCardSelected.Raise();
        }
        
        public override void OnHighlight(CardDistance inst) {
            
        }
    }
}