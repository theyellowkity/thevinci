﻿import UnityEngine;
import System.Collections;


    
    public abstract class ElementsLogic extends ScriptableObject {
        
        public abstract void OnClick(CardDistance inst);
        
        public abstract void OnHighlight(CardDistance inst);
    }
}