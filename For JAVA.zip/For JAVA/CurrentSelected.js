﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;
public class CurrentSelected extends MonoBehaviour {
    
    public CardVariable currentCard;
    
    public Cardvis cardVis;
    
    public Transform mTransform;
    
    public final void LoadCard() {
        if ((this.currentCard.value == null)) {
            return;
        }
        
        this.currentCard.value.gameObject.SetActive(false);
        this.cardVis.LoadCard(this.currentCard.value.vis.card);
        this.cardVis.gameObject.SetActive(true);
    }
    
    public final void CloseCard() {
        this.cardVis.gameObject.SetActive(false);
    }
    
    private final void Start() {
        this.mTransform = this.transform;
        this.CloseCard();
    }
    
    final void Update() {
        this.mTransform.position = Input.mousePosition;
    }
}