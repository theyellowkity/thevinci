﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;

   
    public class FloatVariable extends NumberVariable {
        
        public float value;
        
        public final void Set(float v) {
            this.value = v;
        }
        
        public final void Set(NumberVariable v) {
            if ((v instanceof FloatVariable)) {
                FloatVariable f = ((FloatVariable)(v));
                this.value = f.value;
            }
            
            if ((v instanceof IntVariable)) {
                IntVariable i = ((IntVariable)(v));
                this.value = i.value;
            }
            
        }
        
        public final void Add(float v) {
            this.value = (this.value + v);
        }
        
        public final void Add(NumberVariable v) {
            if ((v instanceof FloatVariable)) {
                FloatVariable f = ((FloatVariable)(v));
                this.value = (this.value + f.value);
            }
            
            if ((v instanceof IntVariable)) {
                IntVariable i = ((IntVariable)(v));
                this.value = (this.value + i.value);
            }
            
        }
    }
}