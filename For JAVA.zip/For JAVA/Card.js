﻿import UnityEngine;
import System.Collections.Generic;
import System.Collections;


public class Card extends ScriptableObject () {
    
    public CardType cardType;
    
    public CardProperties[] properties;
}