﻿import UnityEngine;
import System.Collections;
import cb.GameStates;


    public class State extends ScriptableObject {
        
        public Action[] actions;
        
        public final void Tick(float d) {
            for (int i = 0; (i < this.actions.Length); i++) {
                this.actions[i].Execute(d);
            }
            
        }
    }
}