﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;
import cb.GameStates;

public class GameManager extends MonoBehaviour {
    
    public State currentState;
    
    private final void Start() {
        Settings.gameManager = this;
    }
    
    private final void Update() {
        this.currentState.Tick(Time.deltaTime);
    }
    
    public final void SetState(State state) {
        this.currentState = state;
    }
}