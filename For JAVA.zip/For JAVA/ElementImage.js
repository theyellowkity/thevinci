﻿import UnityEngine;
import System.Collections;

public class ElementImage extends Element {
}