﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;
import UnityEngine.EventSystems;

public class Settings {
    
    public static GameManager gameManager;
    
    private static ResourcesManager _resourcesManager;
    
    public static ResourcesManager GetResourcesManager() {
        if ((_resourcesManager == null)) {
            _resourcesManager = ((ResourcesManager)(Resources.Load("ResourceManager")));
        }
        
        return _resourcesManager;
    }
    
    public static List<RaycastResult> GetUIObjs() {
        PointerEventData pointerData = new PointerEventData(EventSystem.current);
        List<RaycastResult> results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(pointerData, results);
        return results;
    }
}