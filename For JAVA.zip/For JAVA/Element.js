﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;

public abstract class Element extends ScriptableObject {
}