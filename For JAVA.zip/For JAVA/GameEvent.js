﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;


    

    public class GameEvent extends ScriptableObject {
        
        List<GameEventListener> listeners = new List<GameEventListener>();
        
        public final void Register(GameEventListener l) {
            this.listeners.Add(l);
        }
        
        public final void UnRegister(GameEventListener l) {
            this.listeners.Remove(l);
        }
        
        public final void Raise() {
            for (int i = 0; (i < this.listeners.Count); i++) {
                this.listeners[i].Response();
            }
            
        }
    }
}