﻿import UnityEngine;
import System.Collections.Generic;
import UnityEngine.EventSystems;
import cb.GameStates;

public class MouseDetection extends Action {
    
    public override void Execute(float d) {
        List<RaycastResult> results = Settings.GetUIObjs();
        Clickable c = null;
        for (RaycastResult r : results) {
            c = r.gameObject.GetComponentInParent<Clickable>();
            if ((c != null)) {
                c.OnHighlight();
                break;
            }
            
        }
        
    }
}