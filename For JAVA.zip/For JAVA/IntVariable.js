﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;

namespace SO {
    
  public class IntVariable extends NumberVariable {
        
        public int value;
        
        public final void Set(int v) {
            this.value = v;
        }
        
        public final void Set(NumberVariable v) {
            if ((v instanceof FloatVariable)) {
                FloatVariable f = ((FloatVariable)(v));
                this.value = Mathf.RoundToInt(f.value);
            }
            
            if ((v instanceof IntVariable)) {
                IntVariable i = ((IntVariable)(v));
                this.value = i.value;
            }
            
        }
        
        public final void Add(int v) {
            this.value = (this.value + v);
        }
        
        public final void Add(NumberVariable v) {
            if ((v instanceof FloatVariable)) {
                FloatVariable f = ((FloatVariable)(v));
                this.value = (this.value + Mathf.RoundToInt(f.value));
            }
            
            if ((v instanceof IntVariable)) {
                IntVariable i = ((IntVariable)(v));
                this.value = (this.value + i.value);
            }
            
        }
    }
}