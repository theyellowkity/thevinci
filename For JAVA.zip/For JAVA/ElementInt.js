﻿import UnityEngine;
import System.Collections;


public class ElementInt extends Element {
}