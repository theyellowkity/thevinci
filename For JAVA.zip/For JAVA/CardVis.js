﻿import UnityEngine;
import System.Collections;
import UnityEngine.UI;
import System;
public class Cardvis extends MonoBehaviour {
    
    public Card card;
    
    public CardVisProperties[] properties;
    
    public GameObject statsHolder;
    
    private final void Start() {
        this.LoadCard(this.card);
    }
    
    internal final CardVisProperties GetProperty(object t) {
        throw new NotImplementedException();
    }
    
    public final void LoadCard(Card c) {
        if ((c == null)) {
            return;
        }
        
        this.card = c;
        c.cardType.OnSetType(this);
        for (int i = 0; (i < c.properties.Length); i++) {
            CardProperties cp = c.properties[i];
            CardVisProperties p = this.GetProperty(cp.element);
            if ((p == null)) {
                // TODO: Warning!!! continue If
            }
            
            if ((cp.element instanceof ElementInt)) {
                p.text.text = cp.intValue.ToString();
            }
            else if ((cp.element instanceof ElementText)) {
                p.text.text = cp.stringValue;
            }
            else if ((cp.element instanceof ElementImage)) {
                p.img.sprite = cp.sprite;
            }
            
        }
        
    }
    
    public final CardVisProperties GetProperty(Element e) {
        CardVisProperties result = null;
        for (int i = 0; (i < this.properties.Length); i++) {
            if ((this.properties[i].element == e)) {
                result = this.properties[i];
                break;
            }
            
        }
        
        return result;
    }
}