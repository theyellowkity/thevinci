﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;


public class ResourcesManager extends ScriptableObject {
    
    public Element typeElement;
}