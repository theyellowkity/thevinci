﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;

    public class SpriteVariable extends ScriptableObject {
        
        public Sprite value;
        
        public final void Set(Sprite v) {
            this.value = v;
        }
        
        public final void Set(SpriteVariable v) {
            this.value = v.value;
        }
    }
}