﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;

public abstract class CardType extends ScriptableObject {
    
    public string typeName;
    
    public virtual void OnSetType(Cardvis vis) {
        
    }
}