﻿import UnityEngine;
import System.Collections;


    public class MyCardDown extends ElementsLogic {
        
        public override void OnClick(CardDistance inst) {
            Debug.Log("This card also is mine but on the table");
        }
        
        public override void OnHighlight(CardDistance inst) {
            
        }
    }
}