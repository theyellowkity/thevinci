﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;
import UnityEngine.Events;

    
    public class ConditionalEvent_BoolVariable extends EventExecutionOnMB {
        
        public BoolVariable targetBool;
        
        public UnityEvent IfTrue;
        
        public UnityEvent IfFalse;
        
        ///  <summary>
        ///  Use this to raise either a true or false event stack based on a bool variable
        ///  </summary>
        public override void Raise() {
            if ((this.targetBool == null)) {
                Debug.Log(("Bool Variable not assigned on Conditional Event " + this.gameObject.name));
                return;
            }
            
            if (this.targetBool.value) {
                this.IfTrue.Invoke();
            }
            else {
                this.IfFalse.Invoke();
            }
            
        }
    }
}