﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;

namespace SO {
    
    
    public class BoolVariable extends ScriptableObject {
        
        public boolean value;
        
        public final void Set(boolean v) {
            this.value = v;
        }
        
        public final void Set(BoolVariable v) {
            this.value = v.value;
        }
        
        public final void Reverse() {
            this.value = !this.value;
        }
        
        public final boolean Compare(boolean v) {
            return (v == this.value);
        }
        
        public final boolean Compare(BoolVariable v) {
            return (this.value == v.value);
        }
    }