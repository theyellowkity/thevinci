﻿import System.Collections;
import System.Collections.Generic;
import UnityEngine;
import UnityEngine.EventSystems;


    public class MouseHold extends Action {
        
        public State playerControlState;
        
        public SO.GameEvent onPlayerControlState;
        
        public override void Execute(float d) {
            boolean mouseIsDown = Input.GetMouseButton(0);

            if (!mouseIsDown) {
                List<RaycastResult> results = Settings.GetUIObjs();
                for (RaycastResult r : results) {
                    // check the dropping area
                }
                
                Settings.gameManager.SetState(this.playerControlState);
                this.onPlayerControlState.Raise();
                return;
            }
            
        }
    }
}